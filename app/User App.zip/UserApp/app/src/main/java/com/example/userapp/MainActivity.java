package com.example.userapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.material.internal.NavigationMenu;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    DrawerLayout drawer;
    NavigationView navigationView;
    FirebaseUser currentUser;
    private static final String TAG = "MainActivity";
    GoogleSignInClient mGoogleSignInClient;
    FirebaseAuth.AuthStateListener mAuthStateListener;
    FirebaseAuth mAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();

        mAuthStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {

                if(firebaseAuth.getCurrentUser() == null){

                    Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                    startActivity(intent);

                }

            }
        };

        if(currentUser != null) {

            drawer = findViewById(R.id.drawerLayout);
            navigationView = findViewById(R.id.navView);

            Toolbar toolbar = findViewById(R.id.mainActivityToolbar);
            setSupportActionBar(toolbar);

            View navHeaderView = navigationView.inflateHeaderView(R.layout.nav_drawer_head);
            ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.open, R.string.close);
            drawer.addDrawerListener(toggle);
            toggle.syncState();


            navigationView.setNavigationItemSelectedListener(MainActivity.this);



        }

        Log.i(TAG, "onCreate: "+ currentUser.getUid());

    }


    @Override
    protected void onStart() {
        // Configure sign-in to request the user's ID, email address, and basic
// profile. ID and basic profile are included in DEFAULT_SIGN_IN.
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();


        // Build a GoogleSignInClient with the options specified by gso.
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
        Log.i(TAG, "onStart: here");
        super.onStart();

        mAuth.addAuthStateListener(mAuthStateListener);


    }


    private void signOut(){
        mAuth.signOut();
        mGoogleSignInClient.signOut();
    }



//    @Override
//    public void onBackPressed() {
//
////        if(drawer.isDrawerOpen(GravityCompat.START)){
////            drawer.closeDrawer(GravityCompat.START);
////        }
////        else
//            super.onBackPressed();
//    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()){

            case R.id.logout :
                Log.i(TAG, "onNavigationItemSelected: Logout Pressed");
                signOut();
                finish();

            break;

        }
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }


}
