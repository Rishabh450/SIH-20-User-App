package com.example.userapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.material.internal.NavigationMenu;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, FirFragment.OnAlertDialogBoxClickedListener {

    DrawerLayout drawer;
    NavigationView navigationView;
    FirebaseUser currentUser;
    private static final String TAG = "MainActivity";
    GoogleSignInClient mGoogleSignInClient;
    FirebaseAuth.AuthStateListener mAuthStateListener;
    FirebaseAuth mAuth;
    FragmentTransaction fragmentTransaction;
    Toolbar toolbar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();

        mAuthStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {

                if(firebaseAuth.getCurrentUser() == null){

                    Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                    startActivity(intent);

                }

            }
        };

        if(currentUser != null) {

            drawer = findViewById(R.id.drawerLayout);
            navigationView = findViewById(R.id.navView);

            toolbar = findViewById(R.id.mainActivityToolbar);
            setSupportActionBar(toolbar);

            View navHeaderView = navigationView.inflateHeaderView(R.layout.nav_drawer_head);
            ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.open, R.string.close);
            drawer.addDrawerListener(toggle);
            toggle.syncState();


            navigationView.setNavigationItemSelectedListener(MainActivity.this);

            fragmentTransaction = getSupportFragmentManager().beginTransaction();
            WantedFragment wantedFragment = new WantedFragment();
            fragmentTransaction.add(R.id.fragment_container, wantedFragment);
            fragmentTransaction.commit();



        }

        Log.i(TAG, "onCreate: "+ currentUser.getUid());

    }


    @Override
    protected void onStart() {
        // Configure sign-in to request the user's ID, email address, and basic
// profile. ID and basic profile are included in DEFAULT_SIGN_IN.
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();


        // Build a GoogleSignInClient with the options specified by gso.
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
        Log.i(TAG, "onStart: here");
        super.onStart();

        mAuth.addAuthStateListener(mAuthStateListener);


    }


    private void signOut(){
        mAuth.signOut();
        mGoogleSignInClient.signOut();
    }



    @Override
    public void onBackPressed() {

        if(drawer.isDrawerOpen(GravityCompat.START)){
            drawer.closeDrawer(GravityCompat.START);
        }
        else
            super.onBackPressed();
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

        fragmentTransaction = getSupportFragmentManager().beginTransaction();


        switch (menuItem.getItemId()){

            case R.id.account:
                AccountFragment accountFragment = new AccountFragment();
                fragmentTransaction.replace(R.id.fragment_container, accountFragment);
                fragmentTransaction.commit();
                toolbar.setTitle("Account");
                break;

            case R.id.file_a_fir:
                FirFragment firFragment = new FirFragment();
                fragmentTransaction.replace(R.id.fragment_container, firFragment);
                fragmentTransaction.commit();
                toolbar.setTitle("FIR");
                break;

            case R.id.logout :
//                Log.i(TAG, "onNavigationItemSelected: Logout Pressed");
                signOut();
                finish();

            break;

        }
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }


    @Override
    public void onClick() {

        Log.i(TAG, "onClick: Clicked");

        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        AccountFragment accountFragment = new AccountFragment();
        fragmentTransaction.replace(R.id.fragment_container, accountFragment);
        fragmentTransaction.commit();
        toolbar.setTitle("Account");

    }
}
